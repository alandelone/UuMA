"""Inspect Crossref matches for DOI-free references in audited PDF parses."""

from __future__ import annotations

import argparse
import json
import time
import urllib.parse
from pathlib import Path

from rstv4.acquisition import DOI_PATTERN, normalize_title
from rstv4.parser_quality import normalize_mineru_result
from rstv4.sources import _get_json, lookup_bibliographic_reference


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--audit", type=Path, required=True)
    parser.add_argument("--samples", type=int, default=5)
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()
    audit = json.loads(args.audit.read_text(encoding="utf-8"))
    output = []
    for sample in audit["results"]:
        content_path = Path(sample["content_path"])
        pdf_path = Path(sample["pdf_path"])
        markdown_path = content_path.with_name(pdf_path.stem + ".md")
        if not markdown_path.exists():
            markdown_path = content_path.with_name(
                content_path.name.removesuffix("_content_list.json") + ".md"
            )
        normalized = normalize_mineru_result(
            {"manifest": {
                "content_list_path": str(content_path),
                "markdown_path": str(markdown_path),
            }},
            source_pdf_path=pdf_path,
        )
        reference = next(
            (ref["raw_text"] for ref in normalized["references"]
             if not DOI_PATTERN.search(ref["raw_text"]) and len(ref["raw_text"]) >= 60),
            None,
        )
        if not reference:
            continue
        if args.strict:
            started = time.perf_counter()
            result = lookup_bibliographic_reference(reference)
            output.append({
                "paper": sample["name"],
                "reference": reference[:320],
                "error": result.error,
                "accepted_doi": result.candidates[0].doi if result.candidates else None,
                "accepted_provider": (
                    result.candidates[0].source_provider if result.candidates else None
                ),
                "accepted_title": result.candidates[0].title if result.candidates else None,
                "elapsed_s": round(time.perf_counter() - started, 3),
            })
            if len(output) >= args.samples:
                break
            continue
        url = "https://api.crossref.org/works?" + urllib.parse.urlencode({
            "query.bibliographic": reference,
            "rows": 3,
            "select": "DOI,title,published,author",
        })
        try:
            items = _get_json(url).get("message", {}).get("items", [])
            error = None
        except (OSError, ValueError) as exc:  # a provider failure remains visible in the probe
            items, error = [], str(exc)
        citation = normalize_title(reference)
        output.append({
            "paper": sample["name"],
            "reference": reference[:320],
            "error": error,
            "matches": [{
                "doi": item.get("DOI"),
                "title": (item.get("title") or [None])[0],
                "title_in_reference": bool(
                    (title := normalize_title((item.get("title") or [""])[0]))
                    and title in citation
                ),
                "year_in_reference": str(
                    (item.get("published") or {}).get("date-parts", [[""]])[0][0]
                ) in reference,
            } for item in items],
        })
        if len(output) >= args.samples:
            break
    print(json.dumps(output, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
