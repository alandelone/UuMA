"""Measure DOI based citation discovery from audited MinerU artifacts.

The inputs are read only. This script does not enqueue jobs or write to Catalog.
"""

from __future__ import annotations

import argparse
import json
import random
import sqlite3
from pathlib import Path

from rstv4.acquisition import DOI_PATTERN, normalize_doi
from rstv4.parser_quality import normalize_mineru_result


def benchmark(audit_path: Path, catalog_path: Path) -> dict:
    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    with sqlite3.connect(catalog_path.as_uri() + "?mode=ro", uri=True) as conn:
        known_dois = {
            doi for (doi,) in conn.execute("SELECT doi FROM papers WHERE doi IS NOT NULL")
        }

    results = []
    all_dois: set[str] = set()
    publishable_dois: set[str] = set()
    for sample in audit["results"]:
        content_path = Path(sample["content_path"])
        pdf_path = Path(sample["pdf_path"])
        markdown_path = content_path.with_name(pdf_path.stem + ".md")
        if not markdown_path.exists():
            markdown_path = content_path.with_name(
                content_path.name.removesuffix("_content_list.json") + ".md"
            )
        normalized = normalize_mineru_result(
            {"manifest": {
                "content_list_path": str(content_path),
                "markdown_path": str(markdown_path),
            }},
            source_pdf_path=pdf_path,
        )
        references = normalized["references"]
        missing = normalized["manifest"]["quality"].get(
            "reference_page_alignment", {}
        ).get("missing_source_numbered_references", [])
        dois = {
            doi
            for ref in references
            if (match := DOI_PATTERN.search(ref["raw_text"]))
            if (doi := normalize_doi(match.group(0)))
        }
        all_dois.update(dois)
        if not missing:
            publishable_dois.update(dois)
        results.append(
            {
                "name": sample["name"],
                "references": len(references),
                "references_with_doi": sum(
                    DOI_PATTERN.search(ref["raw_text"]) is not None for ref in references
                ),
                "unique_dois": len(dois),
                "new_unique_dois": len(dois - known_dois),
                "blocked_missing_numbered_references": missing,
            }
        )

    return {
        "samples": len(results),
        "total_references": sum(row["references"] for row in results),
        "references_with_doi": sum(row["references_with_doi"] for row in results),
        "unique_dois": len(all_dois),
        "new_unique_dois": len(all_dois - known_dois),
        "publishable_unique_dois": len(publishable_dois),
        "publishable_new_unique_dois": len(publishable_dois - known_dois),
        "new_doi_resolution_sample": random.Random(20260928).sample(
            sorted(publishable_dois - known_dois),
            min(5, len(publishable_dois - known_dois)),
        ),
        "known_catalog_dois": len(known_dois),
        "results": results,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--audit", type=Path, required=True)
    parser.add_argument("--catalog", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(benchmark(args.audit, args.catalog), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
