param(
    [string]$PythonExe = (Get-Command python).Source,
    [string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot)
)

$ErrorActionPreference = "Stop"
$venvPath = Join-Path $ProjectRoot ".venv"
$venvPython = Join-Path $venvPath "Scripts\python.exe"

if (-not (Test-Path -LiteralPath $venvPython)) {
    & $PythonExe -m venv $venvPath
    if ($LASTEXITCODE -ne 0) { throw "Unable to create RSTV4 virtual environment." }
}

& $venvPython -m pip install --upgrade pip
& $venvPython -m pip install -e "$ProjectRoot[dev]"
if ($LASTEXITCODE -ne 0) { throw "Unable to install RSTV4 dependencies." }

Write-Host "RSTV4 environment ready: $venvPython"
