"""Run one real literature search through an isolated PaperPool Collection."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from uuid import uuid4

from rstv4.acquisition_worker import AcquisitionWorker
from rstv4.models import CollectionCreateInput, CollectionSearchInput, FieldInput
from rstv4.track_first import TrackFirstService


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--query", required=True)
    parser.add_argument("--providers", nargs="+", required=True)
    parser.add_argument("--limit-per-provider", type=int, default=10)
    args = parser.parse_args()

    root = args.output_root.resolve() / f"search-{uuid4().hex[:12]}"
    started = time.perf_counter()
    root.mkdir(parents=True)
    service = TrackFirstService(root)
    field = service.create_field(FieldInput(name="Isolated discovery probe"))
    collection = service.paperpool.create_collection(
        CollectionCreateInput(
            field_id=field["field_id"],
            name="Isolated discovery probe",
            scope={"question": args.query},
            bibtex="@article{probe,title={Local probe seed},author={Doe, Jane},year={2024}}",
            idempotency_key="isolated-discovery-probe",
        )
    )
    worker = AcquisitionWorker(root, "network", worker_id="discovery-probe-network")
    seed = worker.run_once()
    seed_done = time.perf_counter()
    search = service.paperpool.request_collection_search(
        collection["collection_id"],
        CollectionSearchInput(
            query=args.query,
            providers=args.providers,
            limit_per_provider=args.limit_per_provider,
            idempotency_key="isolated-discovery-query",
        ),
    )
    completed = worker.run_once()
    search_done = time.perf_counter()
    print(json.dumps({
        "root": str(root),
        "seed_status": seed["status"] if seed else None,
        "search_job_id": search["job_id"],
        "search_status": completed["status"] if completed else None,
        "search_result": json.loads(completed["result_json"])
        if completed and completed["result_json"] else None,
        "seed_setup_elapsed_s": round(seed_done - started, 2),
        "search_job_elapsed_s": round(search_done - seed_done, 2),
        "total_elapsed_s": round(search_done - started, 2),
        "usage": service.paperpool.get_usage(collection["collection_id"]),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
