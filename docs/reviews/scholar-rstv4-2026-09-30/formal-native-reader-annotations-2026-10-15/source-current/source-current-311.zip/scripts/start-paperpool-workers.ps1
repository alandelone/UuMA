param(
    [string]$Root = (Split-Path -Parent $PSScriptRoot)
)

$python = Join-Path $Root ".venv\Scripts\python.exe"
if (-not (Test-Path -LiteralPath $python)) {
    throw "RSTV4 virtual environment is missing: $python"
}

$runDir = Join-Path $Root ".rstv4-local\workers"
New-Item -ItemType Directory -Force -Path $runDir | Out-Null
$workers = @(
    @{ Role = "network"; Slot = "1" },
    @{ Role = "network"; Slot = "2" },
    @{ Role = "parser"; Slot = "1" },
    @{ Role = "model"; Slot = "1" }
)

foreach ($worker in $workers) {
    $name = "$($worker.Role)-$($worker.Slot)"
    $stdout = Join-Path $runDir "$name.out.log"
    $stderr = Join-Path $runDir "$name.err.log"
    $process = Start-Process -FilePath $python -ArgumentList @(
        "-m", "rstv4.acquisition_worker", "--root", $Root,
        "--role", $worker.Role, "--slot", $worker.Slot
    ) -WorkingDirectory $Root -WindowStyle Hidden -RedirectStandardOutput $stdout `
      -RedirectStandardError $stderr -PassThru
    Set-Content -LiteralPath (Join-Path $runDir "$name.pid") -Value $process.Id
}

Write-Output "Started two network workers, one parser worker, and one serial model worker."
