param(
    [string]$CondaExe = "C:\Users\Alandelone\anaconda3\Scripts\conda.exe",
    [string]$SourceEnvironment = "ragent",
    [string]$TargetEnvironment = "ragent-mineru122"
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path -LiteralPath $CondaExe -PathType Leaf)) {
    throw "Conda executable not found: $CondaExe"
}

$environmentList = & $CondaExe env list --json | ConvertFrom-Json
$targetSuffix = [IO.Path]::Combine("envs", $TargetEnvironment)
$targetExists = $environmentList.envs | Where-Object {
    $_.TrimEnd("\", "/").EndsWith($targetSuffix, [StringComparison]::OrdinalIgnoreCase)
}

if (-not $targetExists) {
    & $CondaExe create --name $TargetEnvironment --clone $SourceEnvironment -y
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to clone Conda environment $SourceEnvironment"
    }
}

& $CondaExe run --name $TargetEnvironment python -m pip install --disable-pip-version-check `
    "transformers==4.42.4"
if ($LASTEXITCODE -ne 0) {
    throw "Failed to pin transformers 4.42.4"
}

& $CondaExe run --name $TargetEnvironment python -c `
    "from importlib.metadata import version; assert version('magic-pdf') == '1.2.2'; assert version('transformers') == '4.42.4'; import unimernet; print('MinerU environment ready')"
if ($LASTEXITCODE -ne 0) {
    throw "MinerU environment validation failed"
}
