"""Isolated real-Chrome acceptance probe for the three user-supplied publisher pages.

Setup creates a separate Catalog under .rstv4-local/chrome-live-probes. Start the normal
Network Worker against that root, pair the extension, then use report for evidence.
Nothing is written to the production Catalog by this script.
"""

from __future__ import annotations

import argparse
import json
import sqlite3
from datetime import UTC, datetime
from pathlib import Path

from rstv4.acquisition import normalize_doi, utc_now
from rstv4.database import transaction
from rstv4.models import BrowserAcquisitionInput, CollectionCreateInput, FieldInput
from rstv4.track_first import TrackFirstService

REPO_ROOT = Path(__file__).resolve().parents[1]
PROBE_ROOT = REPO_ROOT / ".rstv4-local" / "chrome-live-probes"
CASES = {
    "ieee": {
        "doi": "10.1109/SGES51519.2020.00054",
        "title": "Advantages and Barriers of Applying Solar Nowcasting in Controlling "
        "Microgrids: Findings From A Survey in 2020",
        "url": "https://ieeexplore.ieee.org/abstract/document/9364540",
    },
    "mdpi": {
        "doi": "10.3390/en15176100",
        "title": "Solar Irradiance Nowcasting System Trial and Evaluation for "
        "Islanded Microgrid Control Purposes",
        "url": "https://www.mdpi.com/1996-1073/15/17/6100",
    },
    "sciencedirect": {
        "doi": "10.1016/j.solener.2023.01.060",
        "title": "Probabilistic solar nowcasting based on all-sky imagers",
        "url": "https://www.sciencedirect.com/science/article/pii/S0038092X23000683",
    },
}


def _isolated_root(value: str) -> Path:
    root = Path(value).expanduser().resolve()
    if not root.is_relative_to(PROBE_ROOT.resolve()) or root == PROBE_ROOT.resolve():
        raise ValueError(f"Live probe root must be a child of {PROBE_ROOT}")
    return root


def setup(root: Path, cases: dict[str, dict[str, str]] | None = None) -> None:
    cases = cases or CASES
    if root.exists() and any(root.iterdir()):
        raise FileExistsError(f"Refusing to reuse a nonempty probe directory: {root}")
    root.mkdir(parents=True, exist_ok=True)
    service = TrackFirstService(root)
    field = service.create_field(FieldInput(name="Chrome PDF acceptance probe"))
    collection = service.paperpool.create_collection(CollectionCreateInput(
        field_id=field["field_id"], name="Publisher PDF acceptance probe",
        dois=[case["doi"] for case in cases.values()],
        idempotency_key="chrome-publisher-pdf-acceptance-probe",
    ))
    seeds = {seed["normalized_value"]: seed for seed in collection["seeds"]}
    requests = {}
    for name, case in cases.items():
        seed = seeds[normalize_doi(case["doi"])]
        paper = service.paperpool.resolve_seed(seed["seed_id"], {
            "doi": case["doi"], "title": case["title"],
            "source_provider": "isolated-chrome-probe",
        })
        request = service.paperpool.request_browser_acquisition(
            collection["collection_id"], BrowserAcquisitionInput(
                paper_id=paper["paper_id"],
                idempotency_key=f"chrome-probe-{name}",
                start_url=case["url"],
            ),
        )
        requests[name] = request["request_id"]
    # resolve_seed schedules ordinary network jobs. This probe exercises the browser bridge only.
    with transaction(service.paperpool.db_path) as conn:
        conn.execute(
            """UPDATE acquisition_jobs SET status='SKIPPED',
               result_json=?,updated_at=? WHERE queue_class='NETWORK' AND status='READY'""",
            (json.dumps({"reason": "isolated browser bridge acceptance probe"}), utc_now()),
        )
    plan = {"root": str(root), "collection_id": collection["collection_id"],
            "requests": requests, "cases": cases}
    (root / "probe-plan.json").write_text(json.dumps(plan, indent=2), encoding="utf-8")
    print(json.dumps(plan, indent=2))


def report(root: Path) -> None:
    plan = json.loads((root / "probe-plan.json").read_text(encoding="utf-8"))
    service = TrackFirstService(root)
    evidence = {}
    with sqlite3.connect(service.paperpool.db_path) as conn:
        conn.row_factory = sqlite3.Row
        for name, request_id in plan["requests"].items():
            request = conn.execute(
                "SELECT status,error_json,paper_id FROM browser_acquisition_requests WHERE request_id=?",
                (request_id,),
            ).fetchone()
            files = [dict(row) for row in conn.execute(
                """SELECT file_version_id,sha256,size_bytes,storage_path,source_url,
                          identity_status,acquisition_method FROM source_file_versions
                   WHERE paper_id=? ORDER BY created_at""",
                (request["paper_id"],),
            )]
            for item in files:
                item["file_exists"] = Path(item["storage_path"]).is_file()
            evidence[name] = {"status": request["status"],
                              "error": json.loads(request["error_json"] or "null"),
                              "files": files}
    output = {"root": str(root), "checked_at": datetime.now(UTC).isoformat(),
              "evidence": evidence}
    (root / "probe-result.json").write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["setup", "report"])
    parser.add_argument("--root", required=True)
    parser.add_argument("--site", choices=sorted(CASES), action="append",
                        help="Publisher case to queue during setup; defaults to all three")
    args = parser.parse_args()
    root = _isolated_root(args.root)
    if args.command == "setup":
        setup(root, {name: CASES[name] for name in args.site} if args.site else None)
    else:
        report(root)


if __name__ == "__main__":
    main()
