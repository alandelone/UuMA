param(
    [string]$Root = (Split-Path -Parent $PSScriptRoot)
)

$launcher = Join-Path $Root "scripts\start-paperpool-workers.ps1"
if (-not (Test-Path -LiteralPath $launcher)) {
    throw "Worker launcher is missing: $launcher"
}
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument (
    "-NoProfile -ExecutionPolicy Bypass -File `"$launcher`" -Root `"$Root`""
)
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
$principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive
Register-ScheduledTask -TaskName "RSTV4 PaperPool Workers" -Action $action `
    -Trigger $trigger -Principal $principal -Force | Out-Null
Write-Output "Installed RSTV4 PaperPool Workers login task."
