# Fixed citation source - software acceptance

## Other software source

G09 software acceptance slot 1: this author note fills a template slot only; no scientific claim or external source is asserted.

### Introduction

Beta software paragraph cites original page 1 [@evidence_b5348fa59b3948ae9540b75a33ca9bd9] and additional source [@evidence_6b169de2b78d452f919391b00916f2c8].

First source [@evidence_6b169de2b78d452f919391b00916f2c8]. Next [@evidence_b5348fa59b3948ae9540b75a33ca9bd9]. Repeat [@evidence_6b169de2b78d452f919391b00916f2c8]. G09 software boundary: preserve the original sources and their conditions; no scientific claim is asserted.

G09 software acceptance slot 4: this author note fills a template slot only; no scientific claim or external source is asserted.

### Software source section 1

G09 software acceptance slot 2: this author note fills a template slot only; no scientific claim or external source is asserted.

### Software source section 3

G09 software acceptance slot 3: this author note fills a template slot only; no scientific claim or external source is asserted.

### Software source section 1

G09 software acceptance slot 9: this paragraph preserves the original empty section in the generated workflow; no scientific claim is asserted.

### Software source section 2

G09 software acceptance slot 5: this author note fills a template slot only; no scientific claim or external source is asserted.

### Software source section 3

G09 software acceptance slot 6: this author note fills a template slot only; no scientific claim or external source is asserted.

### New section

G09 software acceptance slot 7: this author note fills a template slot only; no scientific claim or external source is asserted.

G09 software acceptance slot 8: the original empty paragraph is retained and filled for this workflow test; no scientific claim is asserted.
