# Response to reviewers

## comment_8ecd722c5ea041858723009b72fc4cce
G09 round 2 software opinion: keep the original Alpha source and fixed v3 / r10 baseline.
Preserve every source and condition; link only the actual author change that answers this software request.
No external reviewer or scientific judgment is asserted.
G09 author preview note: this second-round opinion is a software fixture, not an external review.

We added the following software boundary note to the Alpha paragraph: G09 software boundary: preserve the original sources and their conditions; no scientific claim is asserted. The original Alpha author thought and selected source conditions remain intact. The note is additional software acceptance wording; it asserts no scientific finding. Round 2 retains the reviewed v3 / r10 baseline, and this reply is checked against generated v5 / author r62. No external reviewer or scientific judgment is asserted. This review is limited to software behavior.
