# Response to reviewers

## comment_f71edb5758ef41f3b0d96d8cdbed18d5
SOFTWARE_FIXTURE C-LAYOUT: Change only the page margin from standard to narrow. Preserve the exact v6 author content, frozen sentences, sources, conditions, citations and table/figure bytes. Verify actual compiled PDF movement separately from scientific prose amendments. This is software acceptance only; no external review or scientific approval.

SOFTWARE_FIXTURE reply. We changed only the page margins from standard to narrow and actually recompiled the fixed v6 content. The author text, generated sentences, sources, conditions, citation identities and original table/figure bytes remain unchanged. This is presentation-only evidence, not a scientific prose amendment or scientific approval.
